import pygame
import random
import math
import asyncio
import sys

pygame.init()
pygame.font.init()

# Portrait Resolution (Great for mobile & desktop)
WIDTH, HEIGHT = 450, 800
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Dino Jump Adventure!")
clock = pygame.time.Clock()

# Fonts
font = pygame.font.Font(None, 26)
large_font = pygame.font.Font(None, 40)
huge_font = pygame.font.Font(None, 52)
button_font = pygame.font.Font(None, 34)

# Color Palette
WHITE = (255, 255, 255)
BLACK = (20, 20, 20)
YELLOW = (255, 220, 40)
GREEN = (70, 210, 80)
RED = (240, 60, 60)
ORANGE = (255, 140, 20)
CYAN = (0, 220, 255)

class DinoGame:
    def __init__(self):
        self.game_state = "MENU" # MENU, PLAYING, GAMEOVER
        
        # 100% Free Maps (Environments)
        self.maps = [
            {"name": "Desert Oasis", "sky": (255, 243, 205), "ground": (224, 185, 116), "cloud": (255, 255, 255)},
            {"name": "Candy Valley", "sky": (255, 215, 235), "ground": (170, 220, 150), "cloud": (255, 240, 255)},
            {"name": "Ice Glacier", "sky": (210, 240, 255), "ground": (160, 210, 240), "cloud": (255, 255, 255)},
            {"name": "Alien Planet", "sky": (45, 25, 75), "ground": (85, 45, 120), "cloud": (130, 80, 180)}
        ]
        self.map_idx = 0

        # 100% Free Weather Options
        self.weathers = ["Sunny & Clear", "Rainbow Showers", "Gentle Snow", "Magical Stars"]
        self.weather_idx = 0

        # 100% Free Cute Characters
        self.characters = [
            {"name": "Green Rex", "color": (60, 190, 80), "eye": (255, 255, 255), "belly": (140, 230, 120)},
            {"name": "Pinky Dino", "color": (255, 105, 180), "eye": (255, 255, 255), "belly": (255, 182, 193)},
            {"name": "Robo Dino", "color": (0, 200, 240), "eye": (255, 255, 50), "belly": (220, 240, 255)},
            {"name": "Golden Rex", "color": (255, 200, 30), "eye": (255, 255, 255), "belly": (255, 240, 140)}
        ]
        self.char_idx = 0

        # Dino Physics (Kid-Friendly & Forgiving)
        self.ground_y = 520
        self.dino_x = 75
        self.dino_y = self.ground_y - 50
        self.vel_y = 0.0
        self.gravity = 1100.0
        self.jump_power = -560.0
        self.is_ducking = False
        self.is_jumping = False
        
        # Shield & Health System for Kids (3 Hearts)
        self.max_hearts = 3
        self.hearts = self.max_hearts
        self.invulnerable_timer = 0.0

        # World Elements
        self.score = 0
        self.high_score = 0
        self.stars_collected = 0
        self.speed = 280.0
        self.obstacles = []
        self.collectibles = []
        self.decorations = []
        self.weather_particles = []
        
        self.spawn_timer = 0.0
        self.star_timer = 0.0

        # Extra Large Mobile Touch Buttons
        self.jump_btn_rect = pygame.Rect(20, HEIGHT - 145, 195, 120)
        self.duck_btn_rect = pygame.Rect(WIDTH - 215, HEIGHT - 145, 195, 120)

        # Menu UI Buttons
        self.char_btn = pygame.Rect(40, 150, 370, 48)
        self.map_btn = pygame.Rect(40, 210, 370, 48)
        self.weather_btn = pygame.Rect(40, 270, 370, 48)
        self.start_btn = pygame.Rect(WIDTH // 2 - 120, 400, 240, 60)
        self.retry_btn = pygame.Rect(WIDTH // 2 - 120, HEIGHT // 2 + 60, 240, 55)

        self.active_touches = {}
        self.init_environment()

    def init_environment(self):
        self.decorations = [[random.randint(0, WIDTH), random.randint(80, 260), random.randint(25, 45)] for _ in range(5)]
        self.weather_particles = [[random.randint(0, WIDTH), random.randint(0, HEIGHT), random.randint(80, 160)] for _ in range(25)]

    def start_game(self):
        self.hearts = self.max_hearts
        self.score = 0
        self.stars_collected = 0
        self.speed = 280.0
        self.dino_y = self.ground_y - 50
        self.vel_y = 0.0
        self.is_ducking = False
        self.is_jumping = False
        self.invulnerable_timer = 0.0
        self.obstacles.clear()
        self.collectibles.clear()
        self.spawn_timer = 0.0
        self.star_timer = 0.0
        self.active_touches.clear()
        self.game_state = "PLAYING"

    def jump(self):
        if not self.is_jumping:
            self.vel_y = self.jump_power
            self.is_jumping = True

    def draw_dino(self, surface, x, y, char, ducking):
        c_main = char["color"]
        c_belly = char["belly"]
        c_eye = char["eye"]

        if ducking:
            # Low, stretched sliding dino
            pygame.draw.rect(surface, c_main, (x, y + 20, 54, 28), border_radius=8)
            pygame.draw.rect(surface, c_belly, (x + 10, y + 28, 25, 14), border_radius=4)
            # Head
            pygame.draw.circle(surface, c_main, (x + 50, y + 26), 12)
            pygame.draw.circle(surface, c_eye, (x + 54, y + 23), 4)
            pygame.draw.circle(surface, BLACK, (x + 55, y + 23), 2)
            # Feet
            pygame.draw.rect(surface, c_main, (x + 10, y + 44, 10, 6), border_radius=2)
            pygame.draw.rect(surface, c_main, (x + 30, y + 44, 10, 6), border_radius=2)
        else:
            # Tall standing / jumping dino
            # Body
            pygame.draw.rect(surface, c_main, (x + 5, y + 14, 34, 32), border_radius=8)
            pygame.draw.rect(surface, c_belly, (x + 16, y + 20, 18, 22), border_radius=4)
            # Head
            pygame.draw.rect(surface, c_main, (x + 18, y - 4, 28, 22), border_radius=6)
            # Eye
            pygame.draw.circle(surface, c_eye, (x + 38, y + 4), 5)
            pygame.draw.circle(surface, BLACK, (x + 39, y + 4), 2)
            # Snout & Smile
            pygame.draw.rect(surface, c_main, (x + 36, y + 6, 12, 10), border_radius=3)
            # Tail
            pygame.draw.polygon(surface, c_main, [(x + 6, y + 30), (x - 10, y + 24), (x + 6, y + 42)])
            # Legs
            pygame.draw.rect(surface, c_main, (x + 10, y + 42, 8, 10), border_radius=2)
            pygame.draw.rect(surface, c_main, (x + 24, y + 42, 8, 10), border_radius=2)

    def draw_obstacle(self, surface, obs):
        ox, oy, otype = int(obs[0]), int(obs[1]), obs[2]
        if otype == "cactus":
            pygame.draw.rect(surface, (40, 170, 70), (ox + 8, oy, 14, 45), border_radius=4)
            pygame.draw.rect(surface, (40, 170, 70), (ox, oy + 12, 10, 14), border_radius=3)
            pygame.draw.rect(surface, (40, 170, 70), (ox + 20, oy + 18, 10, 14), border_radius=3)
        elif otype == "bird":
            # Flying Pterodactyl
            pygame.draw.circle(surface, (255, 120, 50), (ox + 16, oy + 12), 12)
            pygame.draw.polygon(surface, (255, 160, 50), [(ox + 16, oy + 4), (ox - 8, oy - 6), (ox + 4, oy + 12)])
            pygame.draw.polygon(surface, (255, 160, 50), [(ox + 16, oy + 4), (ox + 34, oy - 6), (ox + 24, oy + 12)])
            pygame.draw.polygon(surface, (255, 220, 0), [(ox + 24, oy + 12), (ox + 36, oy + 12), (ox + 24, oy + 18)])

async def main():
    g = DinoGame()
    last_time = pygame.time.get_ticks()

    running = True
    while running:
        current_time = pygame.time.get_ticks()
        dt = (current_time - last_time) / 1000.0
        last_time = current_time
        dt = min(dt, 0.05)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            # PC Keyboard Controls (Space = Jump, Down = Duck)
            elif event.type == pygame.KEYDOWN:
                if g.game_state == "PLAYING":
                    if event.key in (pygame.K_SPACE, pygame.K_UP):
                        g.jump()
                    elif event.key == pygame.K_DOWN:
                        g.is_ducking = True
                elif g.game_state == "MENU" and event.key == pygame.K_SPACE:
                    g.start_game()
                elif g.game_state == "GAMEOVER" and event.key == pygame.K_SPACE:
                    g.game_state = "MENU"

            elif event.type == pygame.KEYUP:
                if event.key == pygame.K_DOWN:
                    g.is_ducking = False

            # Touch / Mouse Input Handling
            elif event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                if event.type == pygame.FINGERDOWN:
                    pos = (int(event.x * WIDTH), int(event.y * HEIGHT))
                    tid = event.finger_id
                else:
                    pos = pygame.mouse.get_pos()
                    tid = 'mouse'

                g.active_touches[tid] = pos

                if g.game_state == "MENU":
                    if g.char_btn.collidepoint(pos):
                        g.char_idx = (g.char_idx + 1) % len(g.characters)
                    elif g.map_btn.collidepoint(pos):
                        g.map_idx = (g.map_idx + 1) % len(g.maps)
                    elif g.weather_btn.collidepoint(pos):
                        g.weather_idx = (g.weather_idx + 1) % len(g.weathers)
                    elif g.start_btn.collidepoint(pos):
                        g.start_game()

                elif g.game_state == "GAMEOVER":
                    if g.retry_btn.collidepoint(pos):
                        g.game_state = "MENU"

                elif g.game_state == "PLAYING":
                    if g.jump_btn_rect.collidepoint(pos):
                        g.jump()

            elif event.type in (pygame.FINGERUP, pygame.MOUSEBUTTONUP):
                tid = event.finger_id if event.type == pygame.FINGERUP else 'mouse'
                if tid in g.active_touches:
                    del g.active_touches[tid]

        # Check Touch Ducking Status
        if g.game_state == "PLAYING":
            touch_duck = any(g.duck_btn_rect.collidepoint(pos) for pos in g.active_touches.values())
            keys = pygame.key.get_pressed()
            g.is_ducking = touch_duck or keys[pygame.K_DOWN]

            # Dino Jump & Gravity
            g.vel_y += g.gravity * dt
            g.dino_y += g.vel_y * dt
            target_floor = g.ground_y - (30 if g.is_ducking else 50)
            if g.dino_y >= target_floor:
                g.dino_y = target_floor
                g.vel_y = 0.0
                g.is_jumping = False

            # Gradual Kid-Friendly Speed Scaling
            g.speed = min(420.0, 280.0 + (g.score * 0.18))
            g.score += int(18 * dt)
            if g.score > g.high_score:
                g.high_score = g.score

            if g.invulnerable_timer > 0:
                g.invulnerable_timer -= dt

            # Spawn Obstacles (Cactus & Flying Birds)
            g.spawn_timer += dt
            if g.spawn_timer > max(1.6, 2.8 - (g.score / 600.0)):
                obs_type = "bird" if (g.score > 80 and random.random() < 0.35) else "cactus"
                obs_y = g.ground_y - 65 if obs_type == "bird" else g.ground_y - 45
                g.obstacles.append([WIDTH + 30, obs_y, obs_type])
                g.spawn_timer = 0.0

            # Spawn Shiny Collectible Stars
            g.star_timer += dt
            if g.star_timer > 2.2:
                g.collectibles.append([WIDTH + 20, g.ground_y - random.choice([40, 85, 130])])
                g.star_timer = 0.0

            # Move Obstacles
            dino_rect = pygame.Rect(g.dino_x, int(g.dino_y), 45, 28 if g.is_ducking else 46)
            for obs in g.obstacles[:]:
                obs[0] -= g.speed * dt
                obs_rect = pygame.Rect(int(obs[0]), int(obs[1]), 30, 45 if obs[2] == "cactus" else 24)
                
                # Collision Check
                if dino_rect.colliderect(obs_rect):
                    if g.invulnerable_timer <= 0:
                        g.hearts -= 1
                        g.invulnerable_timer = 1.2
                        if g.hearts <= 0:
                            g.game_state = "GAMEOVER"
                if obs[0] < -50:
                    g.obstacles.remove(obs)

            # Collect Shiny Stars
            for st in g.collectibles[:]:
                st[0] -= g.speed * dt
                if dino_rect.colliderect(pygame.Rect(int(st[0] - 12), int(st[1] - 12), 24, 24)):
                    g.stars_collected += 1
                    g.score += 25
                    g.collectibles.remove(st)
                elif st[0] < -30:
                    g.collectibles.remove(st)

        # Move Weather & Cloud Particles
        for c in g.decorations:
            c[0] -= (g.speed * 0.35) * dt
            if c[0] < -60:
                c[0] = WIDTH + 40
                c[1] = random.randint(80, 260)

        for p in g.weather_particles:
            p[1] += p[2] * dt
            p[0] -= (g.speed * 0.5) * dt
            if p[1] > HEIGHT: p[1] = 0; p[0] = random.randint(0, WIDTH)
            if p[0] < 0: p[0] = WIDTH

        # --- DRAWING / RENDERING ---
        cur_map = g.maps[g.map_idx]
        screen.fill(cur_map["sky"])

        # Clouds
        for c in g.decorations:
            pygame.draw.circle(screen, cur_map["cloud"], (int(c[0]), int(c[1])), c[2])
            pygame.draw.circle(screen, cur_map["cloud"], (int(c[0] + 20), int(c[1] - 6)), int(c[2] * 0.8))
            pygame.draw.circle(screen, cur_map["cloud"], (int(c[0] - 20), int(c[1] + 4)), int(c[2] * 0.7))

        # Weather FX
        w_type = g.weathers[g.weather_idx]
        if w_type == "Rainbow Showers":
            for p in g.weather_particles:
                pygame.draw.line(screen, (100, 180, 255), (int(p[0]), int(p[1])), (int(p[0] - 4), int(p[1] + 10)), 2)
        elif w_type == "Gentle Snow":
            for p in g.weather_particles:
                pygame.draw.circle(screen, WHITE, (int(p[0]), int(p[1])), 3)
        elif w_type == "Magical Stars":
            for p in g.weather_particles:
                pygame.draw.circle(screen, YELLOW, (int(p[0]), int(p[1])), 2)

        # Ground Strip
        pygame.draw.rect(screen, cur_map["ground"], (0, g.ground_y, WIDTH, HEIGHT - g.ground_y))
        pygame.draw.line(screen, (100, 80, 60), (0, g.ground_y), (WIDTH, g.ground_y), 4)

        # MAIN MENU (LOBBY)
        if g.game_state == "MENU":
            title = huge_font.render("DINO JUMP!", True, (40, 40, 40))
            screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 50))
            
            sub = font.render("Choose Your Hero & Map!", True, (80, 80, 80))
            screen.blit(sub, (WIDTH // 2 - sub.get_width() // 2, 105))

            # Character Button
            cur_c = g.characters[g.char_idx]
            pygame.draw.rect(screen, (255, 255, 255), g.char_btn, border_radius=10)
            pygame.draw.rect(screen, cur_c["color"], g.char_btn, 3, border_radius=10)
            screen.blit(button_font.render(f"Dino: {cur_c['name']}", True, (40, 40, 40)), (g.char_btn.x + 20, g.char_btn.centery - 12))

            # Map Button
            pygame.draw.rect(screen, (255, 255, 255), g.map_btn, border_radius=10)
            pygame.draw.rect(screen, (220, 160, 60), g.map_btn, 3, border_radius=10)
            screen.blit(button_font.render(f"World: {cur_map['name']}", True, (40, 40, 40)), (g.map_btn.x + 20, g.map_btn.centery - 12))

            # Weather Button
            pygame.draw.rect(screen, (255, 255, 255), g.weather_btn, border_radius=10)
            pygame.draw.rect(screen, (100, 180, 255), g.weather_btn, 3, border_radius=10)
            screen.blit(button_font.render(f"Sky: {w_type}", True, (40, 40, 40)), (g.weather_btn.x + 20, g.weather_btn.centery - 12))

            # Dino Preview
            g.draw_dino(screen, WIDTH // 2 - 20, 330, cur_c, False)

            # Start Game Button
            pygame.draw.rect(screen, GREEN, g.start_btn, border_radius=15)
            st_txt = large_font.render("PLAY NOW!", True, WHITE)
            screen.blit(st_txt, (g.start_btn.centerx - st_txt.get_width() // 2, g.start_btn.centery - st_txt.get_height() // 2))

        # PLAYING GAME
        elif g.game_state == "PLAYING":
            # Draw Stars
            for st in g.collectibles:
                sx, sy = int(st[0]), int(st[1])
                pygame.draw.circle(screen, YELLOW, (sx, sy), 12)
                pygame.draw.circle(screen, WHITE, (sx, sy), 5)

            # Draw Obstacles
            for obs in g.obstacles:
                g.draw_obstacle(screen, obs)

            # Draw Dino (with flash effect if hit)
            if g.invulnerable_timer <= 0 or int(current_time / 100) % 2 == 0:
                g.draw_dino(screen, g.dino_x, int(g.dino_y), g.characters[g.char_idx], g.is_ducking)

            # Extra Large Touch Controls (Bottom Screen)
            # JUMP BUTTON (LEFT)
            pygame.draw.rect(screen, GREEN, g.jump_btn_rect, border_radius=18)
            pygame.draw.rect(screen, WHITE, g.jump_btn_rect, 4, border_radius=18)
            j_txt = large_font.render("JUMP!", True, WHITE)
            screen.blit(j_txt, (g.jump_btn_rect.centerx - j_txt.get_width() // 2, g.jump_btn_rect.centery - j_txt.get_height() // 2))

            # DUCK / DIVE BUTTON (RIGHT)
            pygame.draw.rect(screen, ORANGE, g.duck_btn_rect, border_radius=18)
            pygame.draw.rect(screen, WHITE, g.duck_btn_rect, 4, border_radius=18)
            d_txt = large_font.render("DUCK / SLIDE", True, WHITE)
            screen.blit(d_txt, (g.duck_btn_rect.centerx - d_txt.get_width() // 2, g.duck_btn_rect.centery - d_txt.get_height() // 2))

            # Kid-Friendly HUD (Score, Stars, Hearts)
            screen.blit(large_font.render(f"Score: {g.score}", True, (40, 40, 40)), (25, 25))
            screen.blit(large_font.render(f"Stars: {g.stars_collected}", True, (210, 150, 0)), (25, 65))

            # Draw 3 Big Hearts
            for i in range(g.max_hearts):
                hx = WIDTH - 120 + (i * 35)
                h_col = RED if i < g.hearts else (180, 180, 180)
                pygame.draw.circle(screen, h_col, (hx, 40), 12)

        # GAMEOVER SCREEN
        elif g.game_state == "GAMEOVER":
            gov_txt = huge_font.render("GREAT TRY!", True, (240, 60, 60))
            screen.blit(gov_txt, (WIDTH // 2 - gov_txt.get_width() // 2, HEIGHT // 3 - 30))

            score_txt = large_font.render(f"Your Score: {g.score}", True, (40, 40, 40))
            screen.blit(score_txt, (WIDTH // 2 - score_txt.get_width() // 2, HEIGHT // 3 + 30))

            star_txt = large_font.render(f"Stars Gathered: {g.stars_collected}", True, (210, 150, 0))
            screen.blit(star_txt, (WIDTH // 2 - star_txt.get_width() // 2, HEIGHT // 3 + 70))

            pygame.draw.rect(screen, GREEN, g.retry_btn, border_radius=12)
            r_txt = large_font.render("PLAY AGAIN!", True, WHITE)
            screen.blit(r_txt, (g.retry_btn.centerx - r_txt.get_width() // 2, g.retry_btn.centery - r_txt.get_height() // 2))

        pygame.display.flip()
        await asyncio.sleep(0)

if __name__ == "__main__":
    asyncio.run(main())